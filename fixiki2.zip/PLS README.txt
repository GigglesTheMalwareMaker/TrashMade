 ###############
    &fixiki&
 ###############
Your PC will die after this
Trojan: Noskid
Type: Destructive, i guess
Works Best In Windows XP and 7
it also overwrites your MBR to Make your PC unbootable
If you reboot, Then your MBR died.
DONT RUN ON REAL MACHINE AND RUN ONLY IN VM!